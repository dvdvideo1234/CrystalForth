MPE C to Forth Compiler
=======================

Copyright (c) 2003, 2007
MicroProcessor Engineering
133 Hill Lane
Southampton SO15 5AF
England

tel: +44 (0)23 8063 1441
fax: +44 (0)23 8033 9691
net: mpe@mpeforth.com
     tech-support@mpeforth.com
web: www.mpeforth.com

From North America, our telephone and fax numbers are:
  011 44 23 8063 1441
  011 44 23 8033 9691


Last update
===========
21 April 2007
4 September 2003


What you get
============
The contents of the file c2forth110.zip form a C to Forth
compiler tool chain. The harness (see below) was tested on
a three year old version of VFX Forth for Windows, then
known as ProForth VFX. The harness may need changing for
the current version of VFX Forth. The binaries were last
tested under Windows 95, and may need recompilation under
newer versions of the C compilers.

We are releasing this because there is interest within the
Forth community in the topic of C to Forth translation.
This release is intended to be the basis of a community
project managed by MPE. If someone has the time and
enthusiasm to manage this project elsewhere, e.g.
sourceforge, please contact MPE.

Please return contributions and updates to MPE for
incorporation in later releases.

This is an officially unsupported product, but we'll help
if we have the time and inclination. Enquiries and comments
should be sent to:
  sfp@mpeforth.com


The legal bit
=============
The software is released free of charge for non-commercial
use. For commercial use, a license must be obtained from
MPE.


Contents of distribution:
=========================

\BIN                    C compiler binaries

        CPP             C Preprocessor

        FCC             C Compiler

        OMAKE           Make utility

        C2FPOST         Parsing utility to take FCC output and pad it
                        into a form which can be safely TFTP'd in 512byte
                        packets.

\DOC                    C2F Distribution documentation. See C2FORTH.HTML

\DOC\LIBC               Documentation on sample C library implementation.

\HARNESS                C2F Forth Target Harness, reference source.
                        See C2FORTH.HTML for details.

\INCLUDE                C Header files for sample C library implementation.

\LIB                    Forth source for C library functions.

\SRC                    C source code for tools.

\TESTS                  Some simple test programs and a suitable makefile


