/* TSEPOS 7 17 6 */

/* ***************************************************************************

        CONIO.H      Non-standard console IO functions

        (c) 2000 MicroProcessor Engineering Limited
        133 Hill Lane
        Southampton
        SO15 5AF

************************************************************************** */

#ifndef __CONIO__
#define __CONIO__

extern int kbhit( void );

#endif
