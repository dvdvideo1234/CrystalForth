/* TSEPOS 23 1 22 */

#ifndef __CTYPE__
#define __CTYPE__

extern char isalpha( char t );
extern char isascii( char t );
extern char isblank( char t );
extern char iscntrl( char t );
extern char isdigit( char t );
extern char isxdigit( char t );
extern char isgraph( char t );
extern char islower( char t );
extern char isupper( char t );
extern char isspace( char t );
extern char ispunt( char t );
extern char isprint( char t );
extern char isalnum( char t );
extern char tolower( char t );
extern char toupper( char t );

#endif
