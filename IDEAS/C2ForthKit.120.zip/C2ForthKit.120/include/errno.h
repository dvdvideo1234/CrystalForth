/* TSEPOS 5 17 4 */
#ifndef __ERRNO__
#define __ERRNO__

extern int errno

#endif
