
PUBLIC _char_matrix
LABEL  _char_matrix
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$20 c,
		$20 c,
		$20 c,
		$20 c,
		$20 c,
		$00 c,
		$20 c,
		$00 c,
		$50 c,
		$50 c,
		$50 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$50 c,
		$50 c,
		$F8 c,
		$50 c,
		$F8 c,
		$50 c,
		$50 c,
		$00 c,
		$20 c,
		$78 c,
		$A0 c,
		$70 c,
		$28 c,
		$F0 c,
		$20 c,
		$00 c,
		$C0 c,
		$C8 c,
		$10 c,
		$20 c,
		$40 c,
		$98 c,
		$18 c,
		$00 c,
		$40 c,
		$A0 c,
		$A0 c,
		$40 c,
		$A8 c,
		$90 c,
		$68 c,
		$00 c,
		$30 c,
		$30 c,
		$10 c,
		$20 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$20 c,
		$40 c,
		$80 c,
		$80 c,
		$80 c,
		$40 c,
		$20 c,
		$00 c,
		$20 c,
		$10 c,
		$08 c,
		$08 c,
		$08 c,
		$10 c,
		$20 c,
		$00 c,
		$20 c,
		$A8 c,
		$70 c,
		$20 c,
		$70 c,
		$A8 c,
		$20 c,
		$00 c,
		$00 c,
		$20 c,
		$20 c,
		$70 c,
		$20 c,
		$20 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$30 c,
		$30 c,
		$10 c,
		$20 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$70 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$30 c,
		$30 c,
		$00 c,
		$00 c,
		$08 c,
		$10 c,
		$20 c,
		$40 c,
		$80 c,
		$00 c,
		$00 c,
		$70 c,
		$88 c,
		$98 c,
		$A8 c,
		$C8 c,
		$88 c,
		$70 c,
		$00 c,
		$20 c,
		$60 c,
		$20 c,
		$20 c,
		$20 c,
		$20 c,
		$70 c,
		$00 c,
		$70 c,
		$88 c,
		$08 c,
		$30 c,
		$40 c,
		$80 c,
		$F8 c,
		$00 c,
		$F8 c,
		$10 c,
		$20 c,
		$30 c,
		$08 c,
		$88 c,
		$70 c,
		$00 c,
		$10 c,
		$30 c,
		$50 c,
		$90 c,
		$F8 c,
		$10 c,
		$10 c,
		$00 c,
		$F8 c,
		$80 c,
		$F0 c,
		$08 c,
		$08 c,
		$88 c,
		$70 c,
		$00 c,
		$38 c,
		$40 c,
		$80 c,
		$F0 c,
		$88 c,
		$88 c,
		$70 c,
		$00 c,
		$F8 c,
		$08 c,
		$10 c,
		$20 c,
		$40 c,
		$40 c,
		$40 c,
		$00 c,
		$70 c,
		$88 c,
		$88 c,
		$70 c,
		$88 c,
		$88 c,
		$70 c,
		$00 c,
		$70 c,
		$88 c,
		$88 c,
		$78 c,
		$08 c,
		$10 c,
		$E0 c,
		$00 c,
		$00 c,
		$60 c,
		$60 c,
		$00 c,
		$60 c,
		$60 c,
		$00 c,
		$00 c,
		$00 c,
		$60 c,
		$60 c,
		$00 c,
		$60 c,
		$60 c,
		$40 c,
		$00 c,
		$10 c,
		$20 c,
		$40 c,
		$80 c,
		$40 c,
		$20 c,
		$10 c,
		$00 c,
		$00 c,
		$00 c,
		$F8 c,
		$00 c,
		$F8 c,
		$00 c,
		$00 c,
		$00 c,
		$40 c,
		$20 c,
		$10 c,
		$08 c,
		$10 c,
		$20 c,
		$40 c,
		$00 c,
		$70 c,
		$88 c,
		$10 c,
		$20 c,
		$20 c,
		$00 c,
		$20 c,
		$00 c,
		$70 c,
		$88 c,
		$A8 c,
		$B8 c,
		$B0 c,
		$80 c,
		$78 c,
		$00 c,
		$20 c,
		$70 c,
		$88 c,
		$88 c,
		$F8 c,
		$88 c,
		$88 c,
		$00 c,
		$F0 c,
		$88 c,
		$88 c,
		$F0 c,
		$88 c,
		$88 c,
		$F0 c,
		$00 c,
		$70 c,
		$88 c,
		$80 c,
		$80 c,
		$80 c,
		$88 c,
		$70 c,
		$00 c,
		$F0 c,
		$48 c,
		$48 c,
		$48 c,
		$48 c,
		$48 c,
		$F0 c,
		$00 c,
		$F8 c,
		$80 c,
		$80 c,
		$F0 c,
		$80 c,
		$80 c,
		$F8 c,
		$00 c,
		$F8 c,
		$80 c,
		$80 c,
		$F0 c,
		$80 c,
		$80 c,
		$80 c,
		$00 c,
		$78 c,
		$80 c,
		$80 c,
		$80 c,
		$98 c,
		$88 c,
		$78 c,
		$00 c,
		$88 c,
		$88 c,
		$88 c,
		$F8 c,
		$88 c,
		$88 c,
		$88 c,
		$00 c,
		$70 c,
		$20 c,
		$20 c,
		$20 c,
		$20 c,
		$20 c,
		$70 c,
		$00 c,
		$08 c,
		$08 c,
		$08 c,
		$08 c,
		$08 c,
		$88 c,
		$78 c,
		$00 c,
		$88 c,
		$90 c,
		$A0 c,
		$C0 c,
		$A0 c,
		$90 c,
		$88 c,
		$00 c,
		$80 c,
		$80 c,
		$80 c,
		$80 c,
		$80 c,
		$80 c,
		$F8 c,
		$00 c,
		$88 c,
		$D8 c,
		$A8 c,
		$A8 c,
		$88 c,
		$88 c,
		$88 c,
		$00 c,
		$88 c,
		$88 c,
		$C8 c,
		$A8 c,
		$98 c,
		$88 c,
		$88 c,
		$00 c,
		$70 c,
		$88 c,
		$88 c,
		$88 c,
		$88 c,
		$88 c,
		$70 c,
		$00 c,
		$F0 c,
		$88 c,
		$88 c,
		$F0 c,
		$80 c,
		$80 c,
		$80 c,
		$00 c,
		$70 c,
		$88 c,
		$88 c,
		$88 c,
		$A8 c,
		$90 c,
		$68 c,
		$00 c,
		$F0 c,
		$88 c,
		$88 c,
		$F0 c,
		$A0 c,
		$90 c,
		$88 c,
		$00 c,
		$70 c,
		$88 c,
		$80 c,
		$70 c,
		$08 c,
		$88 c,
		$70 c,
		$00 c,
		$F8 c,
		$20 c,
		$20 c,
		$20 c,
		$20 c,
		$20 c,
		$20 c,
		$00 c,
		$88 c,
		$88 c,
		$88 c,
		$88 c,
		$88 c,
		$88 c,
		$70 c,
		$00 c,
		$88 c,
		$88 c,
		$88 c,
		$88 c,
		$88 c,
		$50 c,
		$20 c,
		$00 c,
		$88 c,
		$88 c,
		$88 c,
		$A8 c,
		$A8 c,
		$D8 c,
		$88 c,
		$00 c,
		$88 c,
		$88 c,
		$50 c,
		$20 c,
		$50 c,
		$88 c,
		$88 c,
		$00 c,
		$88 c,
		$88 c,
		$50 c,
		$20 c,
		$20 c,
		$20 c,
		$20 c,
		$00 c,
		$F8 c,
		$08 c,
		$10 c,
		$20 c,
		$40 c,
		$80 c,
		$F8 c,
		$00 c,
		$78 c,
		$40 c,
		$40 c,
		$40 c,
		$40 c,
		$40 c,
		$78 c,
		$00 c,
		$00 c,
		$80 c,
		$40 c,
		$20 c,
		$10 c,
		$08 c,
		$00 c,
		$00 c,
		$F0 c,
		$10 c,
		$10 c,
		$10 c,
		$10 c,
		$10 c,
		$F0 c,
		$00 c,
		$00 c,
		$00 c,
		$20 c,
		$50 c,
		$88 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$00 c,
		$F8 c,

PUBLIC _bannerchr
FLABEL _bannerchr
:NONAME

	{ $arg1 $arg0 | $loc[ 12 ] -- }
	addr $arg0 	@
	#127
	and
	addr $arg0 	!
	#32
	addr $arg0 	-!
	addr $arg1 	@
	addr $arg0 	@
	#3
	lshift
	CompileAddrLit _char_matrix #0 
	+
	+
	c@
	$loc[ 4 + 	!
	#0
	$loc[ 8 + 	!
LABEL  @2
	$loc[ 4 + 	@
	#128
	and
	#0
	=
	CompileCondBranch @9
	CompileAddrLit @6 #0 
	$loc[ 0 + 	!
	CompileBranch @10
LABEL  @9
	CompileAddrLit @7 #0 
	$loc[ 0 + 	!
LABEL  @10
	$loc[ 0 + 	@
	CompileCall _printf
	drop
	$loc[ 4 + 	@
	#1
	lshift
	$loc[ 4 + 	!
LABEL  @3
	#1
	$loc[ 8 + 	+!
	$loc[ 8 + 	@
	#6
	<
	CompileCondBranch @2
LABEL  @1
; drop


PUBLIC _bannerstr
FLABEL _bannerstr
:NONAME

	{ $arg0 | $loc[ 16 ] -- }
	CompileCall _kbhit
	$loc[ 4 + 	!
	$loc[ 4 + 	@
	#0
	=
	CompileCondBranch @12
	CompileBranch @11
LABEL  @12
	#0
	$loc[ 8 + 	!
LABEL  @14
	addr $arg0 	@
	$loc[ 12 + 	!
	CompileBranch @21
LABEL  @18
	$loc[ 12 + 	@
	c@s
	CompileCall _toupper
	$loc[ 0 + 	!
	$loc[ 8 + 	@
	$loc[ 0 + 	@
	char>cell
	CompileCall _bannerchr
LABEL  @19
	#1
	$loc[ 12 + 	+!
LABEL  @21
	$loc[ 12 + 	@
	c@s
	#0
	<>
	CompileCondBranch @18
	CompileAddrLit @22 #0 
	CompileCall _printf
	drop
LABEL  @15
	#1
	$loc[ 8 + 	+!
	$loc[ 8 + 	@
	#8
	<
	CompileCondBranch @14
LABEL  @11
; drop


PUBLIC _kbempty
FLABEL _kbempty
:NONAME

	{ | $loc[ 4 ] -- }
	CompileBranch @27
LABEL  @26
	CompileCall _getchar
	drop
LABEL  @27
	CompileCall _kbhit
	$loc[ 0 + 	!
	$loc[ 0 + 	@
	#0
	<>
	CompileCondBranch @26
LABEL  @25
; drop


PUBLIC _main
FLABEL _main
:NONAME

	{ | $loc[ 8 ] -- }
	#1
	$loc[ 4 + 	!
	CompileAddrLit @31 #0 
	CompileCall _printf
	drop
	CompileCall _kbempty
	CompileBranch @33
LABEL  @32
	CompileAddrLit @36 #0 
	$loc[ 4 + 	@
	$loc[ 0 + 	!
	$loc[ 0 + 	@
	#1
	+
	$loc[ 4 + 	!
	$loc[ 0 + 	@
	CompileAddrLit @35 #0 
	CompileCall _printf
	drop
	drop
	drop
	CompileAddrLit @37 #0 
	CompileCall _bannerstr
	CompileAddrLit @38 #0 
	CompileCall _bannerstr
	CompileAddrLit @39 #0 
	CompileCall _bannerstr
	CompileAddrLit @40 #0 
	CompileCall _bannerstr
	CompileAddrLit @41 #0 
	CompileCall _bannerstr
	CompileAddrLit @42 #0 
	CompileCall _bannerstr
	CompileAddrLit @43 #0 
	CompileCall _bannerstr
	CompileAddrLit @44 #0 
	CompileCall _bannerstr
	CompileAddrLit @45 #0 
	CompileCall _bannerstr
	CompileAddrLit @46 #0 
	CompileCall _bannerstr
	CompileAddrLit @38 #0 
	CompileCall _bannerstr
	CompileAddrLit @39 #0 
	CompileCall _bannerstr
	CompileAddrLit @47 #0 
	CompileCall _bannerstr
	CompileAddrLit @48 #0 
	CompileCall _bannerstr
	CompileAddrLit @39 #0 
	CompileCall _bannerstr
	CompileAddrLit @49 #0 
	CompileCall _bannerstr
	CompileAddrLit @50 #0 
	CompileCall _bannerstr
	CompileAddrLit @51 #0 
	CompileCall _bannerstr
	CompileAddrLit @52 #0 
	CompileCall _bannerstr
	CompileAddrLit @53 #0 
	CompileCall _bannerstr
	CompileAddrLit @54 #0 
	CompileCall _bannerstr
	CompileAddrLit @55 #0 
	CompileCall _bannerstr
	CompileAddrLit @56 #0 
	CompileCall _bannerstr
	CompileAddrLit @57 #0 
	CompileCall _bannerstr
	CompileAddrLit @58 #0 
	CompileCall _bannerstr
	CompileAddrLit @59 #0 
	CompileCall _bannerstr
	CompileAddrLit @60 #0 
	CompileCall _bannerstr
	CompileAddrLit @61 #0 
	CompileCall _bannerstr
	CompileAddrLit @62 #0 
	CompileCall _bannerstr
	CompileAddrLit @63 #0 
	CompileCall _bannerstr
	CompileAddrLit @64 #0 
	CompileCall _bannerstr
	CompileAddrLit @65 #0 
	CompileCall _bannerstr
	CompileAddrLit @66 #0 
	CompileCall _bannerstr
	CompileAddrLit @67 #0 
	CompileCall _bannerstr
	CompileAddrLit @68 #0 
	CompileCall _bannerstr
	CompileAddrLit @69 #0 
	CompileCall _bannerstr
	CompileAddrLit @61 #0 
	CompileCall _bannerstr
	CompileAddrLit @70 #0 
	CompileCall _bannerstr
	CompileAddrLit @71 #0 
	CompileCall _bannerstr
	CompileAddrLit @72 #0 
	CompileCall _bannerstr
	CompileAddrLit @73 #0 
	CompileCall _bannerstr
	CompileAddrLit @74 #0 
	CompileCall _bannerstr
	CompileAddrLit @51 #0 
	CompileCall _bannerstr
	CompileAddrLit @75 #0 
	CompileCall _bannerstr
	CompileAddrLit @50 #0 
	CompileCall _bannerstr
	CompileAddrLit @76 #0 
	CompileCall _bannerstr
LABEL  @33
	CompileCall _kbhit
	$loc[ 0 + 	!
	$loc[ 0 + 	@
	#0
	=
	CompileCondBranch @32
	CompileCall _kbempty
LABEL  @30
; drop

EXTERN _kbhit
EXTERN _toupper
EXTERN _tolower
EXTERN _isalnum
EXTERN _isprint
EXTERN _ispunt
EXTERN _isspace
EXTERN _isupper
EXTERN _islower
EXTERN _isgraph
EXTERN _isxdigit
EXTERN _isdigit
EXTERN _iscntrl
EXTERN _isblank
EXTERN _isascii
EXTERN _isalpha
EXTERN _putchar
EXTERN _getchar
EXTERN _fprintf
EXTERN _printf
EXTERN _sprintf
EXTERN _puts
EXTERN _stdout
EXTERN _stderr
LABEL  @76
		$76 c,
		$65 c,
		$6C c,
		$76 c,
		$65 c,
		$74 c,
		$65 c,
		$65 c,
		$6E c,
		$2E c,
		$00 c,
LABEL  @75
		$62 c,
		$6F c,
		$64 c,
		$79 c,
		$00 c,
LABEL  @74
		$46 c,
		$72 c,
		$6F c,
		$6D c,
		$00 c,
LABEL  @73
		$61 c,
		$74 c,
		$77 c,
		$69 c,
		$73 c,
		$74 c,
		$00 c,
LABEL  @72
		$6B c,
		$6E c,
		$65 c,
		$65 c,
		$73 c,
		$00 c,
LABEL  @71
		$77 c,
		$69 c,
		$74 c,
		$68 c,
		$00 c,
LABEL  @70
		$73 c,
		$74 c,
		$72 c,
		$61 c,
		$64 c,
		$64 c,
		$6C c,
		$65 c,
		$00 c,
LABEL  @69
		$6C c,
		$65 c,
		$67 c,
		$73 c,
		$00 c,
LABEL  @68
		$46 c,
		$69 c,
		$74 c,
		$00 c,
LABEL  @67
		$62 c,
		$65 c,
		$74 c,
		$77 c,
		$65 c,
		$65 c,
		$6E c,
		$2E c,
		$00 c,
LABEL  @66
		$76 c,
		$65 c,
		$6C c,
		$6C c,
		$75 c,
		$6D c,
		$00 c,
LABEL  @65
		$67 c,
		$6F c,
		$73 c,
		$73 c,
		$61 c,
		$6D c,
		$65 c,
		$72 c,
		$00 c,
LABEL  @64
		$53 c,
		$74 c,
		$69 c,
		$74 c,
		$63 c,
		$68 c,
		$00 c,
LABEL  @63
		$77 c,
		$72 c,
		$69 c,
		$73 c,
		$74 c,
		$3B c,
		$00 c,
LABEL  @62
		$62 c,
		$61 c,
		$6E c,
		$73 c,
		$68 c,
		$65 c,
		$65 c,
		$00 c,
LABEL  @61
		$74 c,
		$6F c,
		$00 c,
LABEL  @60
		$66 c,
		$69 c,
		$6E c,
		$67 c,
		$65 c,
		$72 c,
		$73 c,
		$00 c,
LABEL  @59
		$62 c,
		$61 c,
		$77 c,
		$6B c,
		$69 c,
		$65 c,
		$00 c,
LABEL  @58
		$53 c,
		$65 c,
		$77 c,
		$00 c,
LABEL  @57
		$68 c,
		$6F c,
		$6D c,
		$65 c,
		$2E c,
		$00 c,
LABEL  @56
		$63 c,
		$61 c,
		$72 c,
		$65 c,
		$66 c,
		$75 c,
		$6C c,
		$6C c,
		$79 c,
		$00 c,
LABEL  @55
		$69 c,
		$74 c,
		$00 c,
LABEL  @54
		$73 c,
		$6D c,
		$75 c,
		$67 c,
		$67 c,
		$6C c,
		$65 c,
		$00 c,
LABEL  @53
		$41 c,
		$6E c,
		$64 c,
		$00 c,
LABEL  @52
		$6C c,
		$65 c,
		$70 c,
		$72 c,
		$65 c,
		$63 c,
		$68 c,
		$61 c,
		$75 c,
		$6E c,
		$00 c,
LABEL  @51
		$61 c,
		$00 c,
LABEL  @50
		$6F c,
		$66 c,
		$00 c,
LABEL  @49
		$6E c,
		$6F c,
		$73 c,
		$65 c,
		$00 c,
LABEL  @48
		$42 c,
		$6F c,
		$72 c,
		$72 c,
		$6F c,
		$77 c,
		$00 c,
LABEL  @47
		$67 c,
		$6E c,
		$6F c,
		$6D c,
		$65 c,
		$3B c,
		$00 c,
LABEL  @46
		$65 c,
		$61 c,
		$72 c,
		$73 c,
		$00 c,
LABEL  @45
		$70 c,
		$6F c,
		$69 c,
		$6E c,
		$74 c,
		$65 c,
		$64 c,
		$00 c,
LABEL  @44
		$48 c,
		$69 c,
		$73 c,
		$00 c,
LABEL  @43
		$66 c,
		$61 c,
		$63 c,
		$65 c,
		$2C c,
		$00 c,
LABEL  @42
		$63 c,
		$72 c,
		$69 c,
		$6E c,
		$6B c,
		$6C c,
		$79 c,
		$00 c,
LABEL  @41
		$68 c,
		$69 c,
		$73 c,
		$00 c,
LABEL  @40
		$67 c,
		$6F c,
		$62 c,
		$6C c,
		$69 c,
		$6E c,
		$00 c,
LABEL  @39
		$74 c,
		$68 c,
		$65 c,
		$00 c,
LABEL  @38
		$66 c,
		$72 c,
		$6F c,
		$6D c,
		$00 c,
LABEL  @37
		$54 c,
		$61 c,
		$6B c,
		$65 c,
		$00 c,
LABEL  @36
		$42 c,
		$41 c,
		$4E c,
		$4E c,
		$45 c,
		$52 c,
		$20 c,
		$31 c,
		$2E c,
		$34 c,
		$20 c,
		$31 c,
		$39 c,
		$39 c,
		$38 c,
		$30 c,
		$37 c,
		$31 c,
		$37 c,
		$00 c,
LABEL  @35
		$0A c,
		$0A c,
		$25 c,
		$64 c,
		$3A c,
		$20 c,
		$25 c,
		$73 c,
		$0A c,
		$0A c,
		$0A c,
		$00 c,
LABEL  @31
		$0A c,
		$48 c,
		$65 c,
		$6C c,
		$6C c,
		$6F c,
		$0A c,
		$00 c,
LABEL  @22
		$0D c,
		$0A c,
		$00 c,
LABEL  @7
		$20 c,
		$00 c,
LABEL  @6
		$23 c,
		$00 c,
