
#define VERSION   "1.00." BUILDNO
#define COPYRIGHT "Copyright (C) 1998 MicroProcessor Engineering Ltd."

